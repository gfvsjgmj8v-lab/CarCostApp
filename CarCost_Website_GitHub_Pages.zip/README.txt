CARCOST WEBSITE

1. Create a public GitHub repository named carcost.
2. Upload the CONTENTS of this folder to the repository root (index.html, support.html, privacy.html, style.css and .webp images).
3. In Settings > Pages, select Deploy from a branch, main, /(root).
4. Your links will be https://YOUR-USERNAME.github.io/carcost/ and https://YOUR-USERNAME.github.io/carcost/support.html

IMPORTANT: privacy.html is a DRAFT CHECKLIST, NOT A FINAL PRIVACY POLICY. Replace with accurate disclosures before App Store submission. Check screenshot accuracy, claims and legal requirements.
